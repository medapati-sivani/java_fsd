package com;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ConfigurableApplicationContext context = 
		         new ClassPathXmlApplicationContext("Beans.xml");
		 context.start();
		  
	      Helloworld obj = (Helloworld) context.getBean("helloworld");
	      System.out.println(obj);

	      // Let us raise a stop event.
	      context.stop();
	}

}
