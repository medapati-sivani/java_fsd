package com;

public class Helloworld {
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "Helloworld [message=" + message + "]";
	}
}
