package com;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class DemoTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Employee emp1=new Employee();
		//emp1.display();
		Resource rs=new ClassPathResource("beans.xml");    //loading the xml file
		BeanFactory bb=new XmlBeanFactory(rs);            //getting bean factory reference
		/*Employee employe1=(Employee)bb.getBean("emp1");    //type casting
		employe1.display();                //Here we are not creating objects just pulling from xml
		Employee employe2=(Employee)bb.getBean("emp2");    //type casting
		employe2.display(); 
		Employee employe3=(Employee)bb.getBean("emp2");    //type casting
		employe3.display(); 
		Employee employe4=(Employee)bb.getBean("emp1");    //type casting
		employe4.display(); 
		*/
		/*Employee employe5=(Employee)bb.getBean("emp1");    //type casting
		System.out.println(employe5);                      //It will call tostring method
		Employee employe6=(Employee)bb.getBean("emp3");    //type casting
		System.out.println(employe6);
		*/
		//Employee employe7=(Employee)bb.getBean("emp4");
		//System.out.println(employe7);
		
		/*Address address1=(Address)bb.getBean("add1");
		System.out.println(address1);
		Employee employe8=(Employee)bb.getBean("emp7");
		System.out.println(employe8);*/
		
		Employee employe9=(Employee)bb.getBean("emp8");
		System.out.println(employe9);
		
	}

}
