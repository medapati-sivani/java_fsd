package com.simplilearn.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.simplilearn.demo.User;


@Repository//as it is a repository we need to use @repository annotation
public interface UserRepo extends JpaRepository<User, Integer> {//i prepared interface of userrepository now this is used in service

}